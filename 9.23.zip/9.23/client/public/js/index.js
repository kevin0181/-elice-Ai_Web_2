$(document).ready(() => { // <= 1. index.html이 로딩이 되면 실행

    // 2. ajax를 통해서 서버에 posts의 list를 요청하는 부분
    $.ajax({
        url: `http://localhost:8080/posts`,
        type: "GET",
        success: (res) => {
            // 4. posts의 list를 응답 받음.
            console.log(res);

            res.map((data, index) => {

                $("#table-id").append(`
                <tr>
                    <th scope="row">${index + 1}</th>
                    <td>
                        <a href='#'>${data.title}</a>
                    </td>
                    <td>
                        <button type="button" 
                        class="btn btn-outline-warning">
                            수정
                        </button>
                    </td>
                    <td>
                        <button type="button"
                         class="btn btn-outline-danger">
                            삭제
                         </button>
                    </td>
                </tr>
                `)

            })

        },
        error: (e) => {
            console.log(e);
        }
    })

})
